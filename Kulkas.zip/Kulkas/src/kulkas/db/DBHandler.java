
package kulkas.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import kulkas.Kulkas;
import kulkas.model.kulkas;


public class DBHandler {
    public final Connection conn;

    public DBHandler(String driver) {
        this.conn = DBHelper.getConnection(driver);
    }
    public void addkulkas(kulkas t){
        String insertkulkas = "INSERT INTO `produk`(`kd_kulkas`, `nama_produk`, `tgl_produksi`)"
                + "VALUES (?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertkulkas);
            stmtInsert.setString(1, t.getKd_kulkas());
            stmtInsert.setString(2, t.getNama());
            stmtInsert.setString(3, t.getTglProduksi());
            stmtInsert.setString(4, t.getHarga());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void addKulkas(Kulkas t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
